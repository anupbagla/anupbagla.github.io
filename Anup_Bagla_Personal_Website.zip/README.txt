# Anup Bagla — Personal Website

A simple, responsive, single-page website.

## Publish free
The easiest options are GitHub Pages, Netlify, or Cloudflare Pages.

1. Upload `index.html` to a new website repository/project.
2. Replace `YOUR-EMAIL@example.com` with your preferred email.
3. Optionally add a professional photograph and social/profile links.
4. Publish.

The page is intentionally self-contained: no paid theme, plugin, framework, or external asset is required.
